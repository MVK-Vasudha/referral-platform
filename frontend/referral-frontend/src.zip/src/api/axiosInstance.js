import axios from "axios";
import { getToken, clearToken } from "../utils/tokenStorage";

// Create axios instance
const axiosInstance = axios.create({
  baseURL: "http://localhost:8081", // ⚠️ change if your backend runs elsewhere
  headers: {
    "Content-Type": "application/json",
  },
});

// ✅ Request Interceptor — attach JWT
axiosInstance.interceptors.request.use(
  (config) => {
    const token = getToken();

    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }

    return config;
  },
  (error) => Promise.reject(error)
);

// ✅ Response Interceptor — handle auth errors
axiosInstance.interceptors.response.use(
  (response) => response,
  (error) => {
    const status = error.response?.status;

    if (status === 401) {
      clearToken();

      // soft redirect (no window.location hard reload)
      if (window.location.pathname !== "/login") {
        window.location.href = "/login";
      }
    }

    if (status === 403) {
      console.warn("Access forbidden (403)");
    }

    return Promise.reject(error);
  }
);

export default axiosInstance;