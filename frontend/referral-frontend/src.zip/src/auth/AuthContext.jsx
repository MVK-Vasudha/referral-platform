import { createContext, useEffect, useState } from "react";
import {
  login as loginService,
  register as registerService,
} from "../features/auth/services/authService";
import {
  getToken,
  setToken as storeToken,
  clearToken,
} from "../utils/tokenStorage";

export const AuthContext = createContext(null);

export const AuthProvider = ({ children }) => {
  const [token, setTokenState] = useState(null);
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);

  // restore token on app load
  useEffect(() => {
    const existingToken = getToken();

    if (existingToken) {
      setTokenState(existingToken);
    }

    setLoading(false);
  }, []);

  // ✅ LOGIN (no navigation here)
  const login = async (credentials) => {
    const data = await loginService(credentials);

    const jwt = data.token || data.accessToken; 
    if (!jwt) {
      throw new Error("Token not found in response");
    }

    storeToken(jwt);
    setTokenState(jwt);
    setUser(data.user || null);

    return true;
  };

  // ✅ REGISTER (no navigation here)
  const register = async (formData) => {
    await registerService(formData);
    return true;
  };

  // ✅ LOGOUT
  const logout = () => {
    clearToken();
    setTokenState(null);
    setUser(null);
  };

  const value = {
    token,
    user,
    login,
    register,
    logout,
    isAuthenticated: !!token,
    loading,
  };

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
};