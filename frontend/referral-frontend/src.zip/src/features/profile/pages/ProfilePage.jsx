import { useEffect, useState } from "react";
import { getMyProfile } from "../services/profileService";
import EditProfileForm from "./EditProfileForm";

const ProfilePage = () => {
  const [profile, setProfile] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  const fetchProfile = async () => {
    try {
      setLoading(true);
      setError("");
      const data = await getMyProfile();
      setProfile(data);
    } catch (err) {
      setError("Failed to load profile");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchProfile();
  }, []);

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <p>Loading profile...</p>
      </div>
    );
  }

  if (error) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <p className="text-red-500">{error}</p>
      </div>
    );
  }

  if (!profile) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <p>No profile data available</p>
      </div>
    );
  }

  return (
    <div className="min-h-screen p-8 max-w-2xl mx-auto">
      <h1 className="text-2xl font-semibold mb-4">My Profile</h1>

      <div className="border p-4 rounded space-y-2">
        <p><strong>Name:</strong> {profile.fullName}</p>
        <p><strong>Email:</strong> {profile.email}</p>
        <p><strong>Headline:</strong> {profile.headline}</p>
        <p><strong>Location:</strong> {profile.location}</p>
        <p><strong>Bio:</strong> {profile.bio}</p>
      </div>

      <EditProfileForm
        profile={profile}
        onUpdateSuccess={(updated) => {
          setProfile(updated);
        }}
      />
    </div>
  );
};

export default ProfilePage;