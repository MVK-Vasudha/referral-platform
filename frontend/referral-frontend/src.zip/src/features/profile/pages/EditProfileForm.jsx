import { useState } from "react";
import { updateMyProfile } from "../services/profileService";

const EditProfileForm = ({ profile, onUpdateSuccess }) => {
  const [formData, setFormData] = useState({
    fullName: profile?.fullName || "",
    headline: profile?.headline || "",
    bio: profile?.bio || "",
    location: profile?.location || "",
  });

  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const handleChange = (e) => {
    setFormData((prev) => ({
      ...prev,
      [e.target.name]: e.target.value,
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError("");

    try {
      const updatedProfile = await updateMyProfile(formData);
      onUpdateSuccess(updatedProfile);
    } catch (err) {
      setError("Failed to update profile");
    } finally {
      setLoading(false);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4 mt-6">
      <input
        type="text"
        name="fullName"
        value={formData.fullName}
        onChange={handleChange}
        placeholder="Full Name"
        className="border p-2 w-full"
      />

      <input
        type="text"
        name="headline"
        value={formData.headline}
        onChange={handleChange}
        placeholder="Headline"
        className="border p-2 w-full"
      />

      <textarea
        name="bio"
        value={formData.bio}
        onChange={handleChange}
        placeholder="Bio"
        className="border p-2 w-full"
      />

      <input
        type="text"
        name="location"
        value={formData.location}
        onChange={handleChange}
        placeholder="Location"
        className="border p-2 w-full"
      />

      {error && <p className="text-red-500 text-sm">{error}</p>}

      <button
        type="submit"
        disabled={loading}
        className="bg-black text-white px-4 py-2"
      >
        {loading ? "Updating..." : "Update Profile"}
      </button>
    </form>
  );
};

export default EditProfileForm;