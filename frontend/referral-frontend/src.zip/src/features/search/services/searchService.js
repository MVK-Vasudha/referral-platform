import axiosInstance from "../../../api/axiosInstance";

/**
 * GET /users/search?page=&size=&keyword=
 */
export const searchUsers = async ({ page = 0, size = 10, keyword = "" }) => {
  const response = await axiosInstance.get("/users/search", {
    params: { page, size, keyword },
  });

  // Unwrap ApiResponse
  return response.data.data;
};