import { useEffect, useState } from "react";
import { searchUsers } from "../services/searchService";

const SearchPage = () => {
  const [keyword, setKeyword] = useState("");
  const [page, setPage] = useState(0);
  const [size] = useState(10);

  const [results, setResults] = useState([]);
  const [totalPages, setTotalPages] = useState(0);
  const [currentPage, setCurrentPage] = useState(0);

  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const fetchUsers = async () => {
    try {
      setLoading(true);
      setError("");

      const data = await searchUsers({ page, size, keyword });

      setResults(data.content);
      setTotalPages(data.totalPages);
      setCurrentPage(data.number);
    } catch (err) {
      setError("Failed to fetch users");
    } finally {
      setLoading(false);
    }
  };

  // Fetch when page changes
  useEffect(() => {
    fetchUsers();
  }, [page]);

  // Reset page when keyword changes
  useEffect(() => {
    setPage(0);
  }, [keyword]);

  useEffect(() => {
    fetchUsers();
  }, [keyword]);

  return (
    <div className="min-h-screen p-8 max-w-4xl mx-auto">
      <h1 className="text-2xl font-semibold mb-6">Search Users</h1>

      {/* Search Input */}
      <input
        type="text"
        value={keyword}
        onChange={(e) => setKeyword(e.target.value)}
        placeholder="Search by name, headline..."
        className="border p-2 w-full mb-6"
      />

      {/* Loading */}
      {loading && <p>Loading users...</p>}

      {/* Error */}
      {error && <p className="text-red-500">{error}</p>}

      {/* Empty State */}
      {!loading && results.length === 0 && (
        <p>No users found.</p>
      )}

      {/* Results */}
      <div className="space-y-4">
        {results.map((user) => (
          <div key={user.id} className="border p-4 rounded">
            <p><strong>{user.fullName}</strong></p>
            <p>{user.headline}</p>
            <p className="text-sm text-gray-500">{user.location}</p>
          </div>
        ))}
      </div>

      {/* Pagination Controls */}
      {totalPages > 1 && (
        <div className="flex items-center justify-between mt-6">
          <button
            disabled={currentPage === 0}
            onClick={() => setPage((prev) => prev - 1)}
            className="px-4 py-2 border disabled:opacity-50"
          >
            Previous
          </button>

          <span>
            Page {currentPage + 1} of {totalPages}
          </span>

          <button
            disabled={currentPage + 1 >= totalPages}
            onClick={() => setPage((prev) => prev + 1)}
            className="px-4 py-2 border disabled:opacity-50"
          >
            Next
          </button>
        </div>
      )}
    </div>
  );
};

export default SearchPage;