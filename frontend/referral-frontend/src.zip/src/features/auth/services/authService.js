import axiosInstance from "../../../api/axiosInstance";

/**
 * Login user
 * @param {{ email: string, password: string }} credentials
 */
export const login = async (credentials) => {
  try {
    const response = await axiosInstance.post("/auth/login", credentials);

    const apiResponse = response.data;

    // REMOVE success check
    // backend doesn't send "success" field

    return apiResponse.data;
  } catch (error) {
    const message =
      error.response?.data?.message ||
      error.message ||
      "Login failed";

    throw new Error(message);
  }
};

/**
 * Register user
 * @param {{ username: string, email: string, password: string }} data
 */
export const register = async (data) => {
  try {
    const response = await axiosInstance.post("/auth/register", data);

    const apiResponse = response.data;

    if (!apiResponse.success) {
      throw new Error(apiResponse.message || "Registration failed");
    }

    return apiResponse.data;
  } catch (error) {
    const message =
      error.response?.data?.message ||
      error.message ||
      "Registration failed";

    throw new Error(message);
  }
};