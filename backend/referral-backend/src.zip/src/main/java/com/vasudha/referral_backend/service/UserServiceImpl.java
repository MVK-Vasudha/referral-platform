package com.vasudha.referral_backend.service;

import com.vasudha.referral_backend.dto.UserProfileResponse;
import com.vasudha.referral_backend.dto.UserProfileUpdateRequest;
import com.vasudha.referral_backend.dto.UserSearchResponseDTO;
import com.vasudha.referral_backend.entity.User;
import com.vasudha.referral_backend.exception.ResourceNotFoundException;
import com.vasudha.referral_backend.repository.ConnectionRequestRepository;
import com.vasudha.referral_backend.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.*;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@RequiredArgsConstructor
@Transactional
public class UserServiceImpl implements UserService {

    private final UserRepository userRepository;
    private final ConnectionRequestRepository connectionRepository;

    @Override
    @Transactional(readOnly = true)
    public UserProfileResponse getUserProfileByUsername(String username) {

        User user = userRepository.findByUsername(username)
                .orElseThrow(() -> new ResourceNotFoundException("User not found"));

        long connectionCount =
                connectionRepository.countConnections(user.getId());

        return new UserProfileResponse(
                user.getId(),
                user.getUsername(),
                user.getFullName(),
                user.getEmail(),
                user.getHeadline(),
                user.getCompany(),
                user.getSkills(),
                user.getRole().name(),
                user.getCreatedAt().toString(),
                connectionCount
        );
    }

    @Override
    public UserProfileResponse updateUserProfileByUsername(
            String username,
            UserProfileUpdateRequest request
    ) {

        User user = userRepository.findByUsername(username)
                .orElseThrow(() -> new ResourceNotFoundException("User not found"));

        user.setFullName(request.getFullName());
        user.setHeadline(request.getHeadline());
        user.setCompany(request.getCompany());
        user.setSkills(request.getSkills());

        userRepository.save(user);

        long connectionCount =
                connectionRepository.countConnections(user.getId());

        return new UserProfileResponse(
                user.getId(),
                user.getUsername(),
                user.getFullName(),
                user.getEmail(),
                user.getHeadline(),
                user.getCompany(),
                user.getSkills(),
                user.getRole().name(),
                user.getCreatedAt().toString(),
                connectionCount
        );
    }

    @Override
    @Transactional(readOnly = true)
    public Page<UserSearchResponseDTO> searchUsers(
            String name,
            String skills,
            String company,
            String headline,
            Pageable pageable,
            Long currentUserId) {

        Pageable stablePageable;

        if (pageable.getSort().isUnsorted()) {
            stablePageable = PageRequest.of(
                    pageable.getPageNumber(),
                    pageable.getPageSize(),
                    Sort.by(Sort.Direction.DESC, "id")
            );
        } else {
            stablePageable = pageable;
        }

        return userRepository.searchUsers(
                name,
                skills,
                company,
                headline,
                currentUserId,
                stablePageable
        );
    }
}