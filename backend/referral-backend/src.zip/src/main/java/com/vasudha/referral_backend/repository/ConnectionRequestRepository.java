package com.vasudha.referral_backend.repository;

import com.vasudha.referral_backend.entity.ConnectionRequest;
import com.vasudha.referral_backend.entity.ConnectionStatus;
import com.vasudha.referral_backend.entity.User;
import org.springframework.data.domain.*;
import org.springframework.data.jpa.repository.*;
import org.springframework.data.repository.query.Param;

import java.util.Optional;

public interface ConnectionRequestRepository
        extends JpaRepository<ConnectionRequest, Long> {

    boolean existsBySenderIdAndReceiverId(Long senderId, Long receiverId);

    boolean existsBySenderIdAndReceiverIdAndStatus(
            Long senderId, Long receiverId, ConnectionStatus status
    );

    @EntityGraph(attributePaths = {"sender", "receiver"})
    @Query("""
    SELECT cr FROM ConnectionRequest cr
    WHERE (cr.sender.id = :userId OR cr.receiver.id = :userId)
    AND cr.status = 'ACCEPTED'
""")
    Page<ConnectionRequest> findAcceptedConnections(
            @Param("userId") Long userId,
            Pageable pageable
    );


    @EntityGraph(attributePaths = {"sender", "receiver"})
    @Query("""
    SELECT cr FROM ConnectionRequest cr
    WHERE cr.receiver.id = :userId
    AND cr.status = 'PENDING'
""")
    Page<ConnectionRequest> findPendingRequests(
            @Param("userId") Long userId,
            Pageable pageable
    );

    @Query("""
    SELECT u FROM User u
    WHERE u.id IN (
        SELECT CASE
            WHEN cr.sender.id = :userId THEN cr.receiver.id
            ELSE cr.sender.id
        END
        FROM ConnectionRequest cr
        WHERE (cr.sender.id = :userId OR cr.receiver.id = :userId)
        AND cr.status = 'ACCEPTED'
    )
""")
    Page<User> findMutualConnections(
            @Param("userId") Long userId,
            Pageable pageable
    );

    @Query("""
    SELECT COUNT(cr)
    FROM ConnectionRequest cr
    WHERE (cr.sender.id = :userId OR cr.receiver.id = :userId)
    AND cr.status = 'ACCEPTED'
""")
    Long countConnections(@Param("userId") Long userId);




    Optional<ConnectionRequest> findById(Long id);
}
