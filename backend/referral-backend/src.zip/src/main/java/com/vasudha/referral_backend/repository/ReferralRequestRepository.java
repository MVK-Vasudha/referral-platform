package com.vasudha.referral_backend.repository;

import com.vasudha.referral_backend.entity.ReferralRequest;
import com.vasudha.referral_backend.entity.User;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ReferralRequestRepository extends JpaRepository<ReferralRequest, Long> {

    Page<ReferralRequest> findByRequester(User requester, Pageable pageable);

    Page<ReferralRequest> findByReceiver(User receiver, Pageable pageable);
}
