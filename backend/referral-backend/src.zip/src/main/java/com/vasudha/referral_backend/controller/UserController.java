package com.vasudha.referral_backend.controller;

import com.vasudha.referral_backend.dto.*;
import com.vasudha.referral_backend.entity.User;
import com.vasudha.referral_backend.exception.ResourceNotFoundException;
import com.vasudha.referral_backend.repository.UserRepository;
import com.vasudha.referral_backend.security.JwtUtil;
import com.vasudha.referral_backend.service.UserService;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.*;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/users")
@RequiredArgsConstructor
public class UserController {

    private final UserService userService;
    private final JwtUtil jwtUtil;
    private final UserRepository userRepository;

    private Long getCurrentUserId(String token) {
        String username = jwtUtil.extractUsername(token.substring(7));

        User user = userRepository.findByUsername(username)
                .orElseThrow(() -> new ResourceNotFoundException("User not found"));

        return user.getId();
    }

    @GetMapping("/me")
    public ResponseEntity<ApiResponse<UserProfileResponse>> getMyProfile(
            @RequestHeader("Authorization") String token
    ) {

        String username = jwtUtil.extractUsername(token.substring(7));

        UserProfileResponse response =
                userService.getUserProfileByUsername(username);

        return ResponseEntity.ok(
                ApiResponse.success(
                        HttpStatus.OK.value(),
                        "Profile fetched successfully",
                        response
                )
        );
    }

    @PutMapping("/me")
    public ResponseEntity<ApiResponse<UserProfileResponse>> updateMyProfile(
            @RequestHeader("Authorization") String token,
            @RequestBody UserProfileUpdateRequest request
    ) {

        String username = jwtUtil.extractUsername(token.substring(7));

        UserProfileResponse response =
                userService.updateUserProfileByUsername(username, request);

        return ResponseEntity.ok(
                ApiResponse.success(
                        HttpStatus.OK.value(),
                        "Profile updated successfully",
                        response
                )
        );
    }

    @GetMapping("/search")
    public ResponseEntity<ApiResponse<Page<UserSearchResponseDTO>>> searchUsers(
            @RequestHeader("Authorization") String token,
            @RequestParam(required = false) String name,
            @RequestParam(required = false) String skills,
            @RequestParam(required = false) String company,
            @RequestParam(required = false) String headline,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size
    ) {

        Long currentUserId = getCurrentUserId(token);

        Pageable pageable = PageRequest.of(
                page,
                size,
                Sort.by(Sort.Direction.DESC, "id")
        );

        Page<UserSearchResponseDTO> results =
                userService.searchUsers(
                        name,
                        skills,
                        company,
                        headline,
                        pageable,
                        currentUserId
                );

        return ResponseEntity.ok(
                ApiResponse.success(
                        HttpStatus.OK.value(),
                        "Users fetched successfully",
                        results
                )
        );
    }
}
