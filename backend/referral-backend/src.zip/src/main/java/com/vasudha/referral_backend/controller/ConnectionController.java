package com.vasudha.referral_backend.controller;

import com.vasudha.referral_backend.dto.ApiResponse;
import com.vasudha.referral_backend.dto.ConnectionDTO;
import com.vasudha.referral_backend.entity.User;
import com.vasudha.referral_backend.exception.ResourceNotFoundException;
import com.vasudha.referral_backend.repository.UserRepository;
import com.vasudha.referral_backend.security.JwtUtil;
import com.vasudha.referral_backend.service.ConnectionService;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.*;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/connections")
@RequiredArgsConstructor
public class ConnectionController {

    private final ConnectionService connectionService;
    private final JwtUtil jwtUtil;
    private final UserRepository userRepository;

    private Long getCurrentUserId(String token) {
        String username = jwtUtil.extractUsername(token.substring(7));

        User user = userRepository.findByUsername(username)
                .orElseThrow(() -> new ResourceNotFoundException("User not found"));

        return user.getId();
    }

    @PostMapping("/request/{userId}")
    public ResponseEntity<ApiResponse<Void>> sendRequest(
            @RequestHeader("Authorization") String token,
            @PathVariable Long userId
    ) {

        Long currentUserId = getCurrentUserId(token);
        connectionService.sendRequest(currentUserId, userId);

        return ResponseEntity.status(HttpStatus.CREATED)
                .body(ApiResponse.success(
                        HttpStatus.CREATED.value(),
                        "Connection request sent",
                        null
                ));
    }

    @PutMapping("/{id}/accept")
    public ResponseEntity<ApiResponse<Void>> accept(
            @RequestHeader("Authorization") String token,
            @PathVariable Long id
    ) {

        Long currentUserId = getCurrentUserId(token);
        connectionService.acceptRequest(id, currentUserId);

        return ResponseEntity.ok(
                ApiResponse.success(
                        HttpStatus.OK.value(),
                        "Connection accepted",
                        null
                )
        );
    }

    @PutMapping("/{id}/reject")
    public ResponseEntity<ApiResponse<Void>> reject(
            @RequestHeader("Authorization") String token,
            @PathVariable Long id
    ) {

        Long currentUserId = getCurrentUserId(token);
        connectionService.rejectRequest(id, currentUserId);

        return ResponseEntity.ok(
                ApiResponse.success(
                        HttpStatus.OK.value(),
                        "Connection rejected",
                        null
                )
        );
    }

    @GetMapping("/me")
    public ResponseEntity<ApiResponse<Page<ConnectionDTO>>> myConnections(
            @RequestHeader("Authorization") String token,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size
    ) {

        Long currentUserId = getCurrentUserId(token);

        Pageable pageable = PageRequest.of(
                page,
                size,
                Sort.by(Sort.Direction.DESC, "createdAt")
        );

        Page<ConnectionDTO> connections =
                connectionService.getMyConnections(currentUserId, pageable);

        return ResponseEntity.ok(
                ApiResponse.success(
                        HttpStatus.OK.value(),
                        "Connections fetched successfully",
                        connections
                )
        );
    }

    // 🔵 NEW — Pending Requests
    @GetMapping("/pending")
    public ResponseEntity<ApiResponse<Page<ConnectionDTO>>> getPendingRequests(
            @RequestHeader("Authorization") String token,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size
    ) {

        Long currentUserId = getCurrentUserId(token);

        Pageable pageable = PageRequest.of(
                page,
                size,
                Sort.by(Sort.Direction.DESC, "createdAt")
        );

        Page<ConnectionDTO> pending =
                connectionService.getPendingRequests(currentUserId, pageable);

        return ResponseEntity.ok(
                ApiResponse.success(
                        HttpStatus.OK.value(),
                        "Pending connection requests fetched successfully",
                        pending
                )
        );
    }

    // 🔵 NEW — Mutual Connections
    @GetMapping("/{userId}/mutual")
    public ResponseEntity<ApiResponse<Page<ConnectionDTO>>> getMutualConnections(
            @RequestHeader("Authorization") String token,
            @PathVariable Long userId,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size
    ) {

        Long currentUserId = getCurrentUserId(token);

        Pageable pageable = PageRequest.of(
                page,
                size,
                Sort.by(Sort.Direction.DESC, "id")
        );

        Page<ConnectionDTO> mutual =
                connectionService.getMutualConnections(userId, pageable);

        return ResponseEntity.ok(
                ApiResponse.success(
                        HttpStatus.OK.value(),
                        "Mutual connections fetched successfully",
                        mutual
                )
        );
    }
}