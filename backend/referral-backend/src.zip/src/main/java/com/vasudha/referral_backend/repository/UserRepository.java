package com.vasudha.referral_backend.repository;

import com.vasudha.referral_backend.dto.UserSearchResponseDTO;
import com.vasudha.referral_backend.entity.User;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.*;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface UserRepository extends JpaRepository<User, Long> {

    boolean existsByUsername(String username);

    boolean existsByEmail(String email);

    Optional<User> findByUsername(String username);

    @Query("""
        SELECT new com.vasudha.referral_backend.dto.UserSearchResponseDTO(
            u.id,
            u.fullName,
            u.email,
            u.headline,
            u.company,
            u.skills
        )
        FROM User u
        WHERE
            (:name IS NULL OR LOWER(u.fullName) LIKE LOWER(CONCAT('%', :name, '%')))
        AND (:skills IS NULL OR LOWER(u.skills) LIKE LOWER(CONCAT('%', :skills, '%')))
        AND (:company IS NULL OR LOWER(u.company) LIKE LOWER(CONCAT('%', :company, '%')))
        AND (:headline IS NULL OR LOWER(u.headline) LIKE LOWER(CONCAT('%', :headline, '%')))
        AND u.id <> :currentUserId
        AND u.id NOT IN (
            SELECT CASE
                WHEN cr.sender.id = :currentUserId THEN cr.receiver.id
                ELSE cr.sender.id
            END
            FROM ConnectionRequest cr
            WHERE (cr.sender.id = :currentUserId OR cr.receiver.id = :currentUserId)
            AND cr.status = 'ACCEPTED'
        )
    """)
    Page<UserSearchResponseDTO> searchUsers(
            @Param("name") String name,
            @Param("skills") String skills,
            @Param("company") String company,
            @Param("headline") String headline,
            @Param("currentUserId") Long currentUserId,
            Pageable pageable
    );
}
