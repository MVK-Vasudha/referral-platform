package com.vasudha.referral_backend.service;

import com.vasudha.referral_backend.dto.ConnectionDTO;
import com.vasudha.referral_backend.entity.*;
import com.vasudha.referral_backend.exception.*;
import com.vasudha.referral_backend.repository.*;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.*;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@RequiredArgsConstructor
@Transactional
public class ConnectionServiceImpl implements ConnectionService {

    private final ConnectionRequestRepository connectionRepository;
    private final UserRepository userRepository;
    private final ActivityLogService activityLogService;

    @Override
    public void sendRequest(Long senderId, Long receiverId) {

        if (senderId.equals(receiverId)) {
            throw new BusinessConflictException("Cannot connect to yourself");
        }

        if (connectionRepository.existsBySenderIdAndReceiverId(senderId, receiverId)
                || connectionRepository.existsBySenderIdAndReceiverId(receiverId, senderId)) {
            throw new BusinessConflictException("Connection already exists or pending");
        }

        User sender = userRepository.findById(senderId)
                .orElseThrow(() -> new ResourceNotFoundException("Sender not found"));

        User receiver = userRepository.findById(receiverId)
                .orElseThrow(() -> new ResourceNotFoundException("Receiver not found"));

        ConnectionRequest request = ConnectionRequest.builder()
                .sender(sender)
                .receiver(receiver)
                .status(ConnectionStatus.PENDING)
                .build();

        connectionRepository.save(request);
    }

    @Override
    public void acceptRequest(Long requestId, Long currentUserId) {

        ConnectionRequest request = connectionRepository.findById(requestId)
                .orElseThrow(() -> new ResourceNotFoundException("Connection request not found"));

        if (!request.getReceiver().getId().equals(currentUserId)) {
            throw new BusinessForbiddenException("Not authorized to accept this request");
        }

        if (request.getStatus() != ConnectionStatus.PENDING) {
            throw new BusinessConflictException("Connection request already processed");
        }

        request.setStatus(ConnectionStatus.ACCEPTED);

        // 🔵 LOG CONNECTION ACCEPTED
        activityLogService.log(
                currentUserId,
                request.getSender().getId(),
                ActivityType.CONNECTION_ACCEPTED.name(),
                "Connection ID: " + request.getId()
        );
    }

    @Override
    public void rejectRequest(Long requestId, Long currentUserId) {

        ConnectionRequest request = connectionRepository.findById(requestId)
                .orElseThrow(() -> new ResourceNotFoundException("Connection request not found"));

        if (!request.getReceiver().getId().equals(currentUserId)) {
            throw new BusinessForbiddenException("Not authorized to reject this request");
        }

        if (request.getStatus() != ConnectionStatus.PENDING) {
            throw new BusinessConflictException("Connection request already processed");
        }

        request.setStatus(ConnectionStatus.REJECTED);
    }

    @Override
    @Transactional(readOnly = true)
    public Page<ConnectionDTO> getPendingRequests(Long userId, Pageable pageable) {

        return connectionRepository.findPendingRequests(userId, pageable)
                .map(cr -> new ConnectionDTO(
                        cr.getId(),
                        cr.getSender().getId(),
                        cr.getSender().getFullName(),
                        cr.getSender().getHeadline(),
                        cr.getSender().getCompany(),
                        cr.getCreatedAt()
                ));
    }

    @Override
    @Transactional(readOnly = true)
    public Page<ConnectionDTO> getMutualConnections(Long userId, Pageable pageable) {

        return connectionRepository.findMutualConnections(userId, pageable)
                .map(user -> new ConnectionDTO(
                        null,
                        user.getId(),
                        user.getFullName(),
                        user.getHeadline(),
                        user.getCompany(),
                        null
                ));
    }

    @Override
    @Transactional(readOnly = true)
    public Page<ConnectionDTO> getMyConnections(Long userId, Pageable pageable) {

        return connectionRepository.findAcceptedConnections(userId, pageable)
                .map(cr -> {
                    User other = cr.getSender().getId().equals(userId)
                            ? cr.getReceiver()
                            : cr.getSender();

                    return new ConnectionDTO(
                            cr.getId(),
                            other.getId(),
                            other.getFullName(),
                            other.getHeadline(),
                            other.getCompany(),
                            cr.getCreatedAt()
                    );
                });
    }
}