package com.vasudha.referral_backend.dto;

public record UserSearchResponseDTO(
        Long id,
        String fullName,
        String email,
        String headline,
        String company,
        String skills
) {}
